export CC=clang
export CXX=clang++
export FC=gfortran-9
export F77=gfortran-9
export MPIRUN=/usr/local/bin/mpirun 
export MPICXX=/usr/local/bin/mpicxx 
export MPIFC=/usr/local/bin/mpif90 
export MPICC=/usr/local/bin/mpicc 
