export CC=gcc
export CXX=g++
export FC=gfortran
export F77=gfortran
