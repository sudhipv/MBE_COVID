#!/bin/sh

set -x
set -u
set -e
