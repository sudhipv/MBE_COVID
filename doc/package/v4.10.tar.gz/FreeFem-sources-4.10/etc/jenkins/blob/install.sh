#!/usr/bin/env bash

make install
