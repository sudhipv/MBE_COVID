export CC=clang
export CXX=clang++
export FC=gfortran-9
export F77=gfortran-9
