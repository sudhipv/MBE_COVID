export CC=gcc-9
export CXX=g++-9
export FC=gfortran-9
export F77=gfortran-9
export MPIRUN=/usr/local/mpich3/bin/mpirun 
export MPICXX=/usr/local/mpich3/bin/mpicxx 
export MPIFC=/usr/local/mpich3/bin/mpif90 
export MPICC=/usr/local/mpich3/bin/mpicc 
