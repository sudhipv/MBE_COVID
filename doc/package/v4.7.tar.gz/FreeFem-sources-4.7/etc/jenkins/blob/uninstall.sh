#!/bin/bash

rm -rf /builds/workspace/freefem
