#!/bin/bash

make check
