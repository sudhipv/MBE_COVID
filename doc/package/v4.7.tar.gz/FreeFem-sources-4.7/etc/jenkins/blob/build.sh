#!/bin/bash

make -j4
