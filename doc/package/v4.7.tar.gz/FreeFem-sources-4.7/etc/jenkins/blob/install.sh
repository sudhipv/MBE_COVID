#!/bin/bash

make install
